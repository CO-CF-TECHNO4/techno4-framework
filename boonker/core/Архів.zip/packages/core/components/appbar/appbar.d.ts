import techno4, {
  CSSSelector,
  techno4EventsClass,
  techno4Plugin,
} from '../app/app-class.js';

export namespace Appbar {
  interface AppMethods {}
  interface AppParams {}
  interface AppEvents {}
}

declare const AppbarComponent: techno4Plugin;
export default AppbarComponent;
