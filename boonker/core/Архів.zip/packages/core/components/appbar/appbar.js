export default {
  name: 'appbar'
};