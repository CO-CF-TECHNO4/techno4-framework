export default {
  name: 'button'
};