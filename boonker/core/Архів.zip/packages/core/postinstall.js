console.log('\u001b[35m\u001b[1m','With love from Ukraine by Techno4.');
console.log('\u001b[22m\u001b[39m\u001b[32m','https://techno4.online');
